﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;
using Task_Mangement.Model;
using static Task_Mangement.Model.taskModel;

namespace Task_Mangement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class taskController : ControllerBase
    {
        private readonly IConfiguration _config;

        public taskController(IConfiguration config)
        {
            _config = config;
        }

        [HttpPost]
        public async Task<IActionResult> UpsertTask([FromBody] TaskDto dto)
        {
            var result = await ExecuteUpsert(dto);
            return Ok(new { message = result });
        }

        [HttpGet("{taskId:int}")]
        public async Task<IActionResult> GetTaskById(int taskId)
        {
            var connStr = _config.GetConnectionString("DefaultConnection");
            await using var conn = new SqlConnection(connStr);
            await using var cmd = new SqlCommand("dbo.usp_GetTaskById", conn)
            {
                CommandType = CommandType.StoredProcedure
            };

            // Add the parameter by name:
            cmd.Parameters.Add(new SqlParameter("@TaskID", SqlDbType.Int) { Value = taskId });

            await conn.OpenAsync();
            await using var reader = await cmd.ExecuteReaderAsync();

            if (!reader.Read())
            {
                return NotFound(new { message = "Task not found" });
            }

            // Map the columns into an anonymous object:
            var result = new
            {
                TaskID = (int)reader["taskID"],
                Title = (string)reader["title"],
                Description = (string)reader["description"],
                DueDate = (DateTime)reader["dueDate"],
                Status = (string)reader["status"],
                Remarks = reader["remarks"] as string,
                CreatedOn = (DateTime)reader["createdOn"],
                UpdatedOn = reader["updatedOn"] as DateTime?,
                CreatedBy = reader["CreatedByEmail"] as string,
                UpdatedBy = reader["UpdatedByEmail"] as string
            };

            return Ok(result);
        }



        [HttpGet("search")]
        public async Task<IActionResult> SearchTasks(string? query = null,int page = 1,int pageSize = 10)
        {
            var connStr = _config.GetConnectionString("DefaultConnection");
            await using var conn = new SqlConnection(connStr);
            await using var cmd = new SqlCommand("dbo.usp_SearchTasks", conn)
            {
                CommandType = CommandType.StoredProcedure
            };

            // map your parameters
            cmd.Parameters.Add(new SqlParameter("@Query", SqlDbType.NVarChar, 200)
            {
                Value = (object?)query ?? DBNull.Value
            });
            cmd.Parameters.Add(new SqlParameter("@Offset", SqlDbType.Int)
            {
                Value = (page - 1) * pageSize
            });
            cmd.Parameters.Add(new SqlParameter("@Limit", SqlDbType.Int)
            {
                Value = pageSize
            });

            await conn.OpenAsync();
            await using var reader = await cmd.ExecuteReaderAsync();

            // 1) read paged tasks
            var tasks = new List<object>();
            while (reader.Read())
            {
                tasks.Add(new
                {
                    TaskID = (int)reader["taskID"],
                    Title = (string)reader["title"],
                    Description = (string)reader["description"],
                    DueDate = (DateTime)reader["dueDate"],
                    Status = (string)reader["status"],
                    Remarks = reader["remarks"] as string,
                    CreatedOn = (DateTime)reader["createdOn"],
                    UpdatedOn = reader["updatedOn"] as DateTime?,
                    CreatedBy = reader["CreatedByEmail"] as string,
                    UpdatedBy = reader["UpdatedByEmail"] as string
                });
            }

            // 2) move to next result-set for total count
            await reader.NextResultAsync();
            int totalCount = 0;
            if (reader.Read())
            {
                totalCount = reader.GetInt32(0);
            }

            return Ok(new
            {
                TotalItems = totalCount,
                Page = page,
                PageSize = pageSize,
                Tasks = tasks
            });
        }




        private async Task<string> ExecuteUpsert(TaskDto dto)
        {
            var connStr = _config.GetConnectionString("DefaultConnection");
            using var conn = new SqlConnection(connStr);
            using var cmd = new SqlCommand("dbo.UpsertTask", conn)
            {
                CommandType = CommandType.StoredProcedure
            };

            cmd.Parameters.AddWithValue("@taskID", (object?)dto.TaskID ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@title", dto.Title);
            cmd.Parameters.AddWithValue("@description", dto.Description);
            cmd.Parameters.AddWithValue("@dueDate", dto.DueDate);
            cmd.Parameters.AddWithValue("@status", (object?)dto.Status ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@remarks", (object?)dto.Remarks ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@userID", dto.UserID);

            await conn.OpenAsync();
            var result = await cmd.ExecuteScalarAsync();
            return result?.ToString() ?? "Unknown result";
        }

        [HttpDelete("{taskId:int}")]
        public async Task<IActionResult> DeleteTask(int taskId)
        {
            var connStr = _config.GetConnectionString("DefaultConnection");
            using var conn = new SqlConnection(connStr);
            using var cmd = new SqlCommand("DELETE FROM taskData WHERE taskID = @taskID", conn);
            cmd.Parameters.AddWithValue("@taskID", taskId);
            await conn.OpenAsync();
            var rows = await cmd.ExecuteNonQueryAsync();
            if (rows == 0) return NotFound();
            return NoContent();
        }

    }
}
