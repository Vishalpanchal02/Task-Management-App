﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using static Task_Mangement.Model.userModel;
using System.Data.SqlClient;
using System.Data;

namespace Task_Mangement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class userController : ControllerBase
    {
        private readonly IConfiguration _config;
        public userController(IConfiguration config)
        {
            _config = config;
        }

        

        [HttpPost("register")]
        public async Task<ActionResult<RegisterResponse>> Register(RegisterRequest req)
        {
            try
            {
                var ConnString = _config.GetConnectionString("DefaultConnection");
                await using var conn = new SqlConnection(ConnString);
                await using var cmd = new SqlCommand("dbo.spCreateUser", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@FirstName", req.FirstName);
                cmd.Parameters.AddWithValue("@LastName", (object?)req.LastName ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@Email", req.Email);
                cmd.Parameters.AddWithValue("@Password", req.Password);

                await conn.OpenAsync();
                var newId = await cmd.ExecuteScalarAsync();
                return new RegisterResponse(true, Convert.ToInt32(newId), null);
            }
            catch (SqlException ex) when (ex.Number == 50000) // our RAISERROR
            {
                return new RegisterResponse(false, null, ex.Message);
            }
            catch (Exception ex)
            {
                // log…
                return StatusCode(500, new RegisterResponse(false, null, "Internal server error"));
            }
        }

        [HttpPost("login")]
        public async Task<ActionResult<LoginResponse>> Login(LoginRequest req)
        {
            var connString = _config.GetConnectionString("DefaultConnection");
            await using var conn = new SqlConnection(connString);
            await using var cmd = new SqlCommand("dbo.spValidateLogin", conn)
            {
                CommandType = CommandType.StoredProcedure
            };
            cmd.Parameters.AddWithValue("@Email", req.Email);
            cmd.Parameters.AddWithValue("@Password", req.Password);

            await conn.OpenAsync();
            await using var reader = await cmd.ExecuteReaderAsync();

            if (!await reader.ReadAsync())
            {
                // Shouldn't happen: proc always SELECTs one row, 
                // but handle defensively
                return new LoginResponse(false);
            }

            // Map the returned columns:
            bool loginSuccess = reader.GetBoolean(reader.GetOrdinal("LoginSuccess"));
            int? userId = reader.IsDBNull(reader.GetOrdinal("UserID"))
                                    ? (int?)null
                                    : reader.GetInt32(reader.GetOrdinal("UserID"));
            string firstName = reader.IsDBNull(reader.GetOrdinal("FirstName"))
                                    ? null
                                    : reader.GetString(reader.GetOrdinal("FirstName"));
            string lastName = reader.IsDBNull(reader.GetOrdinal("LastName"))
                                    ? null
                                    : reader.GetString(reader.GetOrdinal("LastName"));

            var response = new LoginResponse(
                LoginSuccess: loginSuccess,
                UserID: userId,
                FirstName: firstName,
                LastName: lastName
            );

            return response;
        }
    }
}
