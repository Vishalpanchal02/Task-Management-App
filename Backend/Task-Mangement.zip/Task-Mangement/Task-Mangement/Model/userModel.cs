﻿namespace Task_Mangement.Model
{
    public class userModel
    {
        public record RegisterRequest(string FirstName, string LastName, string Email, string Password);
        public record RegisterResponse(bool Success, int? UserId, string? ErrorMessage);
        public record LoginRequest(string Email, string Password);
    
      // Models/LoginResponse.cs
        public record LoginResponse(
            bool LoginSuccess,
            int? UserID = null,
            string FirstName = null,
            string LastName = null
        );
    }
}
