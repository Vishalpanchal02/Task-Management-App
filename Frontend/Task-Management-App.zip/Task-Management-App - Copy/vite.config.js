import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'


// https://vite.dev/config/
export default defineConfig({
  plugins: [react(),tailwindcss(),],
  server: {
    proxy: {
      '/api': {
        target: 'https://localhost:7143', // Your .NET backend
        changeOrigin: true,
        secure: false, // allow self-signed SSL cert
      },
    },
  },
})

