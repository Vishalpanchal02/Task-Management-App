import "./App.css";
import {
  createBrowserRouter,
  RouterProvider,
  Navigate,
} from "react-router-dom";
import Home from "./components/Home";
import Task from "./components/Task";
import Viewtask from "./components/ViewTask";
import Navbar from "./components/Navbar";
import Login from "./components/Login";
import Register from "./components/Register";
const router = createBrowserRouter([
  {
    path: "/",
    element: <Navigate to="/login" replace />,
  },
  {
    path: "/home",
    element: (
      <div className="w-full h-full flex flex-col">
        <Navbar />
        <Home />
      </div>
    ),
  },
  {
    path: "/home/:taskId",
    element: (
      <div className="w-full h-full flex flex-col">
        <Navbar />
        <Home />
      </div>
    ),
  },
  {
    path: "/tasks",
    element: (
      <div className="w-full h-full flex flex-col">
        <Navbar />
        <Task />
      </div>
    ),
  },
  {
    path: "/tasks/:id",
    element: (
      <div className="w-full h-full flex flex-col">
        <Navbar />
        <Viewtask />
      </div>
    ),
  },
  {
    path: "/login",
    element: (
      <div className="w-full h-full flex flex-col">
        <Login />
      </div>
    ),
  },
  {
    path: "/register",
    element: (
      <div className="w-full h-full flex flex-col">
        <Register />
      </div>
    ),
  },
]);

function App() {
  return <RouterProvider router={router} />;
}

export default App;
