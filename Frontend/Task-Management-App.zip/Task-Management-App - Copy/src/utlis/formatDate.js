// utils/formatDate.js
export function FormatDate(dateString) {
  const d = new Date(dateString);
  // e.g. "Apr 30, 2025" or whatever format you want
  return d.toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}
