export const NavbarData = [
  {
    path: "/home",
    title: "Home",
  },
  {
    path: "/tasks",
    title: "Tasks",
  },
];
