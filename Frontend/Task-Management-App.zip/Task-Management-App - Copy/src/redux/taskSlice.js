import { createSlice } from "@reduxjs/toolkit";
import { toast } from "react-hot-toast";

const initialState = {
  tasks: localStorage.getItem("tasks")
    ? JSON.parse(localStorage.getItem("tasks"))
    : [],
};

const taskSlice = createSlice({
  name: "task",
  initialState,
  reducers: {
    addTotasks: (state, action) => {
      const task = action.payload;
      const index = state.tasks.findIndex((item) => item._id === task._id);

      if (index >= 0) {
        // If the course is already in the tasks, do not modify the quantity
        toast.error("task already exist");
        return;
      }
      // If the course is not in the tasks, add it to the tasks
      state.tasks.push(task);

      // Update to localstorage
      localStorage.setItem("tasks", JSON.stringify(state.tasks));
      // show toast
      toast.success("Task Added");
    },

    updatetasks: (state, action) => {
      const task = action.payload;
      const index = state.tasks.findIndex((item) => item._id === task._id);

      if (index >= 0) {
        // If the course is found in the tasks, update it
        state.tasks[index] = task;
        // Update to localstorage
        localStorage.setItem("tasks", JSON.stringify(state.tasks));
        // show toast
        toast.success("Task Updated");
      }
    },
    removeFromtasks: (state, action) => {
      const taskId = action.payload;

      console.log(taskId);
      const index = state.tasks.findIndex((item) => item._id === taskId);

      if (index >= 0) {
        // If the course is found in the tasks, remove it
        state.tasks.splice(index, 1);
        // Update to localstorage
        localStorage.setItem("tasks", JSON.stringify(state.tasks));
        // show toast
        toast.success("Task Deleted");
      }
    },
    resettask: (state) => {
      state.tasks = [];
      // Update to localstorage
      localStorage.removeItem("tasks");
    },
  },
});

export const { addTotasks, removeFromtasks, updatetasks } = taskSlice.actions;

export default taskSlice.reducer;
