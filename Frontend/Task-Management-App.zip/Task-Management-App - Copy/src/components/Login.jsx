import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const { data } = await axios.post(
        "/api/user/login",
        { Email: email, Password: password },
        { timeout: 5000 }
      );

      // normalize success flag
      const success =
        data.success ?? data.Success ?? data.loginSuccess ?? data.LoginSuccess;
      if (success) {
        localStorage.setItem("email", email);
        localStorage.setItem("userID", data.userID);
        localStorage.setItem("name", data.firstName + " " + data.lastName);
        toast.success("Login successful!");
        setTimeout(() => navigate("/home"), 1000);
      } else {
        toast.error("Invalid email or password");
      }
    } catch (err) {
      // axios wraps non-2xx statuses as errors
      if (err.response) {
        // server responded with a status outside 2xx
        toast.error(err.response.data?.message || "Login failed");
      } else if (err.request) {
        // request made but no response
        toast.error("No response. Check your network.");
      } else {
        // something else
        toast.error("Something went wrong.");
      }
      console.error(err);
    }
  };

  return (
    <>
      <ToastContainer position="top-right" autoClose={3000} hideProgressBar />
      <div className="flex items-center justify-center min-h-screen bg-blue-400">
        <div className="bg-white p-8 rounded-2xl shadow-lg w-80">
          <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">
            Login
          </h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <input
              type="email"
              placeholder="Email"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <input
              type="password"
              placeholder="Password"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition"
            >
              Login
            </button>
          </form>
          <p className="text-center text-sm text-gray-600 mt-4">
            Don't have an account?{" "}
            <Link to="/register" className="text-blue-600 hover:underline">
              Register
            </Link>
          </p>
        </div>
      </div>
    </>
  );
};

export default Login;
