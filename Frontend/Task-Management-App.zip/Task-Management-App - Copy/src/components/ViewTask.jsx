// src/components/ViewTask.jsx
import React, { useState, useEffect } from "react";
import { Copy } from "lucide-react";
import toast from "react-hot-toast";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

const ViewTask = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [task, setTask] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    const fetchTask = async () => {
      try {
        const res = await axios.get(`/api/task/${id}`);
        setTask(res.data);
        console.log(res.data);
      } catch (err) {
        if (err.response?.status === 404) {
          setNotFound(true);
        } else {
          console.error(err);
          toast.error("Failed to load task");
        }
      } finally {
        setLoading(false);
      }
    };
    fetchTask();
  }, [id]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full py-10">
        <p className="text-lg">Loading task…</p>
      </div>
    );
  }

  if (notFound || !task) {
    return (
      <div className="w-full h-full py-10 max-w-[800px] mx-auto px-5">
        <p className="text-center text-xl text-red-500">Task not found.</p>
        <div className="text-center mt-4">
          <button
            onClick={() => navigate(-1)}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-full py-10 max-w-[800px] mx-auto px-5 lg:px-0">
      <div className="flex flex-col gap-y-5 items-start">
        {/* Title */}
        <input
          type="text"
          placeholder="Title"
          value={task.title}
          disabled
          className="w-full text-black border border-input rounded-md p-2"
        />

        {/* Description box with copy */}
        <div className="w-full flex flex-col items-start relative rounded bg-opacity-10 border border-[rgba(128,121,121,0.3)] backdrop-blur-2xl">
          {/* Header bar */}
          <div className="w-full rounded-t flex items-center justify-between gap-x-4 px-4 py-2 border-b border-[rgba(128,121,121,0.3)]">
            {/* Window dots */}
            <div className="flex gap-x-[6px] items-center select-none">
              <span className="w-[13px] h-[13px] rounded-full bg-[rgb(255,95,87)]"></span>
              <span className="w-[13px] h-[13px] rounded-full bg-[rgb(254,188,46)]"></span>
              <span className="w-[13px] h-[13px] rounded-full bg-[rgb(45,200,66)]"></span>
            </div>

            {/* Copy button */}
            <button
              className="flex items-center p-1 transition-colors hover:text-success-500"
              onClick={() => {
                navigator.clipboard.writeText(task.description);
                toast.success("Copied to Clipboard");
              }}
            >
              <Copy size={20} />
            </button>
          </div>

          {/* Description textarea */}
          <textarea
            value={task.description}
            disabled
            placeholder="Description…"
            className="w-full p-3 focus-visible:ring-0 bg-transparent resize-none"
            style={{ caretColor: "#000" }}
            rows={10}
          />
        </div>

        {/* Meta info */}
        <div className="text-sm text-gray-600 space-y-1">
          <p>
            <strong>Due Date:</strong>{" "}
            {new Date(task.dueDate).toLocaleDateString()}
          </p>
          <p>
            <strong>Status:</strong> {task.status}
          </p>
          <p>
            <strong>Created On:</strong>{" "}
            {new Date(task.createdOn).toLocaleString()}
          </p>
          <p>
            <strong>Created By:</strong> {task.createdBy}
          </p>

          {task.updatedOn && !isNaN(new Date(task.updatedOn).getTime()) && (
            <p>
              <strong>Updated On:</strong>{" "}
              {new Date(task.updatedOn).toLocaleString()}
            </p>
          )}
          {task.updatedBy && typeof task.updatedBy === "string" && (
            <p>
              <strong>Updated By:</strong> {task.updatedBy}
            </p>
          )}

          {task.remarks && (
            <p>
              <strong>Remarks:</strong> {task.remarks}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default ViewTask;
