import { Calendar, Copy, Eye, PencilLine, Trash2 } from "lucide-react";
import toast from "react-hot-toast";
import { useState, useEffect } from "react";
import axios from "axios";
import { FormatDate } from "../utlis/formatDate";

const Task = () => {
  // local state
  const [tasks, setTasks] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize] = useState(10);
  const [totalItems, setTotalItems] = useState(0);
  const totalPages = Math.ceil(totalItems / pageSize);
  const fetchTasks = async () => {
    try {
      const res = await axios.get("/api/task/search", {
        params: { query: searchTerm || null, page, pageSize },
      });

      setTasks(res.data.tasks ?? []);
      setTotalItems(res.data.totalItems);
      console.log("Fetched tasks:", res.data);
    } catch (err) {
      console.error(err);
      toast.error("Failed to load tasks");
      setTasks([]); // fallback
      setTotalItems(0);
    }
  };
  useEffect(() => {
    fetchTasks();
  }, [searchTerm, page, pageSize]);

  const handleDelete = async (id) => {
    if (!confirm("Are you sure you want to delete this task?")) return;
    try {
      await axios.delete(`/api/task/${id}`);
      toast.success("Task deleted");
      // 1) Remove from tasks array
      // setTasks((prev) => prev.filter((t) => t.taskID !== id));

      // // 2) Decrement totalItems
      // setTotalItems((prev) => prev - 1);

      // // 3) If that was the last item on the page, go back one page:
      // if (tasks.length === 1 && page > 1) {
      //   setPage((p) => p - 1);
      // }
      // if this was the only item on the page and we're not on page 1,
    // go back one page (will auto-fetch via useEffect)
    if (tasks.length === 1 && page > 1) {
      setPage((p) => p - 1);
    } else {
      // otherwise just re-fetch the current page
      fetchTasks();}
    } catch (err) {
      console.error(err);
      toast.error("Delete failed");
    }
  };

  const getSlimPages = (current, total) => {
    const pages = [];

    // 1. Always show first page
    pages.push(1);

    // 2. Leading ellipsis if needed
    if (current > 2) {
      pages.push("…");
    }

    // 3. Show current if not first or last
    if (current !== 1 && current !== total) {
      pages.push(current);
    }

    // 4. Trailing ellipsis if needed
    if (current < total - 1) {
      pages.push("…");
    }

    // 5. Always show last page (but avoid duplicate if total===1)
    if (total !== 1) {
      pages.push(total);
    }

    return pages;
  };

  return (
    <div className="w-full h-full py-10 max-w-[1200px] mx-auto px-5 lg:px-0">
      <div className="flex flex-col gap-y-3">
        {/* Search */}
        <div className="w-full flex gap-3 px-4 py-2 rounded border border-[rgba(128,121,121,0.3)] mt-6">
          <input
            type="search"
            placeholder="Search task here..."
            className="focus:outline-none w-full bg-transparent"
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setPage(1); // reset to first page on new search
            }}
          />
        </div>

        {/* Task List */}
        <div className="flex flex-col border border-[rgba(128,121,121,0.3)] py-4 rounded-[0.4rem]">
          <h2 className="px-4 text-4xl font-bold border-b border-[rgba(128,121,121,0.3)] pb-4">
            All tasks
          </h2>
          <div className="w-full px-4 pt-4 flex flex-col gap-y-5">
            {tasks.length > 0 ? (
              tasks.map((task) => (
                <div
                  key={task.taskID}
                  className="relative border border-[rgba(128,121,121,0.3)] w-full h-40 gap-y-6 justify-between flex flex-col sm:flex-row p-4 rounded-[0.3rem]"
                >
                  {/* Title + Description */}
                  <div className="w-[50%] flex flex-col space-y-3">
                    <p className="text-4xl line-clamp-1 font-semibold mb-2">
                      {task.title}
                    </p>
                    <p className="text-sm font-normal line-clamp-3 max-w-[80%] text-[#707070]">
                      {task.description}
                    </p>
                  </div>

                  {/* Actions + Meta */}
                  <div className="flex flex-col gap-y-4 sm:items-end">
                    <div className="flex gap-2 flex-wrap sm:flex-nowrap">
                      <a
                        href={`/home/${task.taskID}`}
                        className="p-2 rounded-[0.2rem] bg-white border border-[#c7c7c7] hover:bg-transparent group hover:border-blue-500"
                      >
                        <PencilLine
                          className="text-black group-hover:text-blue-500"
                          size={20}
                        />
                      </a>

                      <button
                        className="p-2 rounded-[0.2rem] bg-white border border-[#c7c7c7] hover:bg-transparent group hover:border-pink-500"
                        onClick={() => handleDelete(task.taskID)}
                      >
                        <Trash2
                          className="text-black group-hover:text-pink-500"
                          size={20}
                        />
                      </button>

                      <a
                        href={`/tasks/${task.taskID}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2 rounded-[0.2rem] bg-white border border-[#c7c7c7] hover:bg-transparent group hover:border-orange-500"
                      >
                        <Eye
                          className="text-black group-hover:text-orange-500"
                          size={20}
                        />
                      </a>

                      <button
                        className="p-2 rounded-[0.2rem] bg-white border border-[#c7c7c7] hover:bg-transparent group hover:border-green-500"
                        onClick={() => {
                          navigator.clipboard.writeText(task.description);
                          toast.success("Copied to Clipboard");
                        }}
                      >
                        <Copy
                          className="text-black group-hover:text-green-500"
                          size={20}
                        />
                      </button>
                    </div>

                    <div className="absolute bottom-0 right-0 gap-x-2 flex flex-nowrap text-sm text-gray-600 whitespace-nowrap p-1">
                      <span>
                        Status: <strong>{task.status}</strong>
                      </span>
                      <span className="mx-1">|</span>
                      <span>
                        Due Date: <strong>{FormatDate(task.dueDate)}</strong>
                      </span>
                      <span className="mx-1">|</span>
                      <span>
                        Created By: <strong>{task.createdBy}</strong> On{" "}
                        <strong>{FormatDate(task.createdOn)}</strong>
                      </span>
                      {task.updatedBy != null && (
                        <>
                          <span className="mx-1">|</span>
                          <span>
                            Last Updated By: <strong>{task.updatedBy}</strong>{" "}
                            On <strong>{FormatDate(task.updatedOn)}</strong>
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-2xl text-center w-full text-chileanFire-500">
                No Data Found
              </div>
            )}
          </div>

          {totalPages > 1 && (
            <div className="flex justify-center items-center gap-2 py-4">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="px-3 py-1 bg-gray-200 rounded disabled:opacity-50"
              >
                Prev
              </button>

              {getSlimPages(page, totalPages).map((item, idx) =>
                item === "…" ? (
                  <span key={idx} className="px-2 text-gray-500">
                    …
                  </span>
                ) : (
                  <button
                    key={idx}
                    onClick={() => setPage(item)}
                    className={`px-3 py-1 rounded ${
                      page === item
                        ? "bg-blue-500 text-white"
                        : "bg-gray-200 hover:bg-gray-300"
                    }`}
                  >
                    {item}
                  </button>
                )
              )}

              <button
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="px-3 py-1 bg-gray-200 rounded disabled:opacity-50"
              >
                Next
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Task;
