import { PlusCircle } from "lucide-react";
import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import axios from "axios";
import {
  useSearchParams,
  useParams,
  Navigate,
  useNavigate,
} from "react-router-dom";
import { FormatDate } from "../utlis/formatDate";

const Home = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const { taskId } = useParams();
  const navigate = useNavigate();
  // Form fields
  const [title, setTitle] = useState("");
  const [value, setValue] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [status, setStatus] = useState("Pending");
  const [remarks, setRemarks] = useState("");

  // Metadata (for existing tasks)
  const [createdOn, setCreatedOn] = useState("");
  const [createdBy, setCreatedBy] = useState("");
  const [updatedOn, setUpdatedOn] = useState("");
  const [updatedBy, setUpdatedBy] = useState("");

  // Simple validation: require title, description, dueDate
  const isValid = title.trim() && value.trim() && dueDate;

  // When editing, fetch the task details
  useEffect(() => {
    console.log(taskId);
    if (!taskId) return;

    axios
      .get(`/api/task/${taskId}`)
      .then((res) => {
        const t = res.data;
        setTitle(t.title);
        setValue(t.description);
        setDueDate(t.dueDate.split("T")[0]); // yyyy-mm-dd
        setStatus(t.status);
        setRemarks(t.remarks || "");

        setCreatedOn(t.createdOn);
        setCreatedBy(t.createdBy);
        setUpdatedOn(t.updatedOn);
        setUpdatedBy(t.updatedBy);
      })
      .catch((err) => {
        console.error(err);
        toast.error("Failed to load task");
      });
  }, [taskId]);

  // Create or update task
  const saveTask = () => {
    const payload = {
      taskID: taskId ? Number(taskId) : 0,
      title,
      description: value,
      dueDate,
      status,
      remarks,
      userID: localStorage.getItem("userID"), // replace with real user ID in your auth flow
    };

    const request = taskId
      ? axios.post(`/api/task`, payload)
      : axios.post("/api/task", payload);

    request
      .then(() => {
        toast.success(taskId ? "Task updated" : "Task created", {
          position: "top-right",
        });

        if (taskId) {
          // Refresh metadata only

          return axios.get(`/api/task/${taskId}`);
        } else {
          // Clear form for new task

          setTitle("");
          setValue("");
          setDueDate("");
          setRemarks("");
          setStatus("Pending");
          setSearchParams({});
          return null;
        }
      })
      .then((res) => {
        if (res && res.data) {
          setTimeout(() => navigate("/tasks"), 10);
          setUpdatedOn(res.data.updatedOn);
          setUpdatedBy(res.data.updatedBy);
          setTitle("");
          setValue("");
          setDueDate("");
          setRemarks("");
          setStatus("Pending");
          setSearchParams({});
        }
      })
      .catch((err) => {
        console.error(err);
        toast.error("Save failed");
      });
  };

  // Reset form & URL
  const resetTask = () => {
    setTimeout(() => navigate("/home"), 100);
    setTitle("");
    setValue("");
    setDueDate("");
    setRemarks("");
    setStatus("Pending");
    setSearchParams({});
  };

  return (
    <div className="w-full py-10 max-w-[900px] mx-auto px-5 lg:px-0">
      <div className="flex flex-col gap-y-6">
        {/* Title + Buttons */}
        <div className="flex gap-x-4 items-center">
          <input
            type="text"
            placeholder="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="flex-1 text-black border rounded-md p-2"
          />

          <button
            onClick={saveTask}
            disabled={!isValid}
            className={`px-4 py-2 text-white rounded-lg ${
              isValid
                ? "bg-blue-600 hover:bg-blue-700"
                : "bg-blue-600 opacity-50 cursor-not-allowed"
            }`}
          >
            {taskId ? "Update Task" : "Create Task"}
          </button>

          {taskId && (
            <button
              onClick={resetTask}
              className="p-2 text-white bg-gray-600 rounded hover:bg-gray-700"
            >
              <PlusCircle size={20} />
            </button>
          )}
        </div>

        {/* Content & Settings */}
        <div className="border rounded-lg overflow-hidden">
          {/* Settings bar */}
          <div className="flex items-center justify-between bg-gray-100 px-4 py-2 border-b space-x-4">
            {/* Due Date always visible */}
            <div className="flex items-center gap-x-2">
              <label className="text-sm text-gray-700">Due Date</label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="text-black border rounded p-1"
                min={new Date().toISOString().split("T")[0]}
              />
            </div>

            {/* Only on edit: Status */}
            {taskId && (
              <div className="flex items-center gap-x-2">
                <label className="text-sm text-gray-700">Status</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                  className="border rounded p-1"
                >
                  <option>Pending</option>
                  <option>Completed</option>
                </select>
              </div>
            )}
          </div>

          {/* Description */}
          <textarea
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder="Write your description here…"
            className="w-full h-90 p-3 focus:outline-none"
            style={{ caretColor: "#000" }}
          />
        </div>

        {/* Remarks field below description */}
        <div className="flex flex-col">
          {/* <label className="text-sm text-gray-700 mb-1">Remarks</label> */}
          <input
            type="text"
            placeholder="Remarks"
            value={remarks}
            onChange={(e) => setRemarks(e.target.value)}
            className="border rounded-md p-2 text-black"
          />
        </div>

        {/* Metadata (only when editing) */}
        {taskId && (
          <div className="text-sm text-gray-600 flex flex-wrap justify-between gap-x-4">
            <div>
              <strong>Last Updated On:</strong>{" "}
              {updatedOn ? FormatDate(updatedOn) : "—"} by {updatedBy || "—"}
            </div>
            <div>
              <strong>Created On:</strong> {FormatDate(createdOn)} by{" "}
              {createdBy}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Home;
