import { useState, useRef, useEffect } from "react";
import { NavbarData } from "../data/Navbar";
import { useNavigate, NavLink } from "react-router-dom";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);
  const navigate = useNavigate();
  const handleLogout = () => {
    // Remove the stored user
    localStorage.removeItem("name");
    localStorage.removeItem("email");
    localStorage.removeItem("userID");
    // Any additional logout logic (e.g. clearing auth headers)

    // Redirect to login
    navigate("/login", { replace: true });
  };
  // close if clicking outside
  useEffect(() => {
    const handler = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <div className="w-full h-[45px] flex items-center  px-4 bg-blue-400">
      {/* left-side nav links */}
      <div className="flex gap-x-5">
        {NavbarData.map((link, idx) => (
          <NavLink
            key={idx}
            to={link.path}
            className={({ isActive }) =>
              isActive
                ? "text-black-500 font-semibold text-xl"
                : "text-white font-medium text-xl"
            }
          >
            {link.title}
          </NavLink>
        ))}
      </div>

      <div className="flex-1" />

      {/* user-dropdown */}
      <div className="relative inline-block mr-4" ref={dropdownRef}>
        <div className="flex items-center">
          {/* avatar & label do nothing onClick */}

          {/* only this chevron toggles */}
          <button
            onClick={() => setIsOpen((o) => !o)}
            className="ml-1 focus:outline-none"
          >
            <img
              src="/images/profile-user.png"
              className="w-8 h-8 rounded-full"
              alt="User avatar"
            />
          </button>
        </div>

        {/* dropdown panel */}
        <div
          className={`absolute top-full right-0 mt-2 w-70 bg-white rounded shadow-lg z-10 transform origin-top-right transition-all ${
            isOpen
              ? "opacity-100 scale-100 pointer-events-auto"
              : "opacity-0 scale-95 pointer-events-none"
          }`}
        >
          <div className="p-4 border-b flex items-center">
            <img
              src="/images/profile-user.png"
              className="w-10 h-10 rounded-full"
              alt="User avatar"
            />
            <div className="ml-3">
              <div className="font-semibold">
                {localStorage.getItem("name")}
              </div>
              <div className="text-sm text-gray-600">
                {localStorage.getItem("email")}
              </div>
            </div>
          </div>
          <div className="py-1">
            <button
              className="w-full text-left px-4 py-2 text-sm hover:bg-gray-100"
              onClick={
                /* logout logic */
                handleLogout
              }
            >
              Logout
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
